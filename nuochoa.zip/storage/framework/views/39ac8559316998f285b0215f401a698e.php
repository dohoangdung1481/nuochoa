

<?php $__env->startSection('content'); ?>

    <section id="contact-info">
        <div class="container">
            <h3>Thông tin liên hệ</h3>
            <address>
                <strong>abc</strong><br>
                HỘ KINH DOANH BLANC PERFUME<br>
                GPKD số: 58A8011955<br>
                Ngày cấp: 01/10/2021<br>
                Cấp bởi: UBND TP Trà Vinh<br>
                77 Điện Biên Phủ, P.6, Trà Vinh<br>
                <strong>Điện thoại:</strong> 0966434787<br>
                <strong>Email:</strong> Support@blanc.com<br>
                <strong>For Work:</strong> Outreach@blanc.com.vn
            </address>
        </div>
    </section>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\OneDrive\Máy tính\nuochoa\nuochoa\resources\views/pages/gioithieu.blade.php ENDPATH**/ ?>