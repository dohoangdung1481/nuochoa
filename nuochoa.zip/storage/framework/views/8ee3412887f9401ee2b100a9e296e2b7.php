
<?php $__env->startSection('content'); ?>

<div class="container mt-5 mb-5"> <!-- Thêm mb-5 để footer không chồng lên nội dung -->
    <h1 class="text-center mb-4">Giỏ hàng của bạn</h1>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th class="text-center">Tên sản phẩm</th>
                    <th class="text-center">Số lượng</th>
                    <th class="text-center">Giá</th>
                    <th class="text-center">Tổng cộng</th>
                    <th class="text-center">Tùy chọn</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $total = 0; // Biến lưu tổng tiền
                ?>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $subtotal = $item->price * $item->qty;
                        $total += $subtotal;
                    ?>
                    <tr>
                        <td class="text-center align-middle"><?php echo e($item->name); ?></td>
                        <td class="text-center align-middle">
                            <form action="<?php echo e(route('giohang.update', $item->rowId)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="number" name="qty" value="<?php echo e($item->qty); ?>" min="1" 
                                       class="form-control d-inline text-center" style="width: 70px;">
                                <button type="submit" class="btn btn-sm btn-secondary">Sửa</button>
                            </form>
                        </td>
                        <td class="text-center align-middle"><?php echo e(number_format($item->price, 0, ',', '.')); ?> VND</td>
                        <td class="text-center align-middle"><?php echo e(number_format($subtotal, 0, ',', '.')); ?> VND</td>
                        <td class="text-center align-middle">
                            <form action="<?php echo e(route('giohang.remove', $item->rowId)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="text-end mt-4">
        <h4 class="text-danger">Tổng tiền: <?php echo e(number_format($total, 0, ',', '.')); ?> VND</h4>
        <a href="" class="btn btn-success btn-lg mt-3">Thanh toán</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\OneDrive\Máy tính\nuochoa\nuochoa\resources\views/pages/giohang.blade.php ENDPATH**/ ?>