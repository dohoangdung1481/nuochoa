<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container d-flex align-items-center justify-content-between">
        

        <!-- Toggle button for mobile view -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll"
            aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar Content -->
        <div class="collapse navbar-collapse" id="navbarScroll">
            <!-- Left menu -->
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">TRANG CHỦ</a>
                </li>
                <?php $__currentLoopData = $danhmuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_null($dm->danh_muc_cha_id)): ?>
                        <!-- Kiểm tra danh mục cha -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <?php echo e($dm->ten_danh_muc); ?>

                            </a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $dm->danh_mucs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a class="dropdown-item" href="#"><?php echo e($subDm->ten_danh_muc); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(URL::to('/gioithieu')); ?>">GIỚI THIỆU</a>
                </li>
            </ul>

            <!-- Search form -->
            <form method="GET" class="d-flex align-items-center" role="search" action="<?php echo e(route('search')); ?>">
                <input class="form-control me-2" type="search" placeholder="Tìm kiếm ..."
                    value="<?php echo e(request('search')); ?>" name="search">
                <button class="btn btn-secondary" type="submit">Tìm</button>
            </form>
        </div>
        

        <div class="mx-auto navbar-nav custom-navbar d-flex align-items-center">
            <li class="nav-item navbar-nav  custom-navbar d-flex align-items-center me-4 hover:bg-light">
                <a class="nav-link btn btn-outline-secondary" href="<?php echo e(route('giohang.index')); ?>" type="button">
                    <i class="bi bi-cart-fill" style="font-size: 1.5rem;"></i></a>
            </li>
        </div>
        
        
        <!-- Right menu -->
        <ul class="navbar-nav custom-navbar d-flex align-items-center">
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link fw-bold" href="<?php echo e(route('register')); ?>">
                            <i class="bi bi-person-plus-fill"></i> Đăng ký
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-door-open-fill"></i> Đăng nhập
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <li>
                                <form class="px-4 py-3" method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Mật khẩu</label>
                                        <input type="password" class="form-control" id="password" name="password" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary form-control">Đăng nhập</button>
                                </form>
                                <div class="text-center">
                                    <a href="<?php echo e(route('password.request')); ?>" class="btn btn-link">Quên mật khẩu?</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Trang cá nhân</a></li>
                        <?php if(Auth::user()->usertype == 'admin'): ?>
                            <li><a class="dropdown-item" href="#">Quản lý</a></li>
                        <?php endif; ?>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                Đăng xuất
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\Admin\OneDrive\Máy tính\nuochoa\nuochoa\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>